#!/usr/bin/env node
// Cérebro-IA: ferramentas locais. Node 18+, sem dependências.
//   node tools/cerebro.mjs nova --de claude --para todas --tipo aviso --projeto atleta-ai --assunto "..."
//   node tools/cerebro.mjs validar [--base <commit>]
//   node tools/cerebro.mjs indice
import { readdirSync, readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const RAIZ = fileURLToPath(new URL('..', import.meta.url));
const PASTA = join(RAIZ, 'mensagens');
const TIPOS = ['aviso', 'mudanca', 'handoff', 'pergunta', 'resposta', 'decisao'];
const OBRIGATORIOS = ['id', 'de', 'para', 'tipo', 'projeto', 'assunto', 'data'];
const ID_RE = /^\d{4}-\d{2}-\d{2}-\d{4}-[a-z0-9]+-[a-z]+(-\d{2})?$/;
const SEGREDOS = [
  /AIza[0-9A-Za-z_-]{35}/,
  /\bsk-[A-Za-z0-9_-]{20,}/,
  /\bgh[pousr]_[A-Za-z0-9]{30,}/,
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
  /(api[_-]?key|token|secret|senha|password)\s*[:=]\s*["']?[A-Za-z0-9_\-/+]{16,}/i,
];

const slug = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');

function listarArquivos(dir) {
  if (!existsSync(dir)) return [];
  const saida = [];
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) saida.push(...listarArquivos(p));
    else if (e.name.endsWith('.md')) saida.push(p);
  }
  return saida.sort();
}

function lerMensagem(caminho) {
  const texto = readFileSync(caminho, 'utf8').replace(/\r\n/g, '\n');
  const m = texto.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
  if (!m) return { caminho, erro: 'cabeçalho ausente: o arquivo deve começar com ---' };
  const campos = {};
  for (const linha of m[1].split('\n')) {
    if (!linha.trim()) continue;
    const i = linha.indexOf(':');
    if (i < 1) return { caminho, erro: `linha inválida no cabeçalho: "${linha}"` };
    campos[linha.slice(0, i).trim()] = linha.slice(i + 1).trim().replace(/^["']|["']$/g, '');
  }
  return { caminho, campos, corpo: m[2], texto };
}

function validar({ base } = {}) {
  const erros = [];
  const avisos = [];
  const msgs = listarArquivos(PASTA).map(lerMensagem);
  const ids = new Set(msgs.filter((m) => m.campos?.id).map((m) => m.campos.id));

  for (const m of msgs) {
    const rel = relative(RAIZ, m.caminho).split(sep).join('/');
    const err = (t) => erros.push(`${rel}: ${t}`);
    if (m.erro) { err(m.erro); continue; }
    const c = m.campos;

    for (const k of OBRIGATORIOS) if (!c[k]) err(`campo obrigatório ausente: ${k}`);

    if (c.id) {
      if (!ID_RE.test(c.id)) {
        err(`id fora do padrão AAAA-MM-DD-HHMM-de-tipo: ${c.id}`);
      } else {
        const partes = c.id.split('-');
        const nome = rel.split('/').pop().replace(/\.md$/, '');
        if (nome !== c.id) err(`o nome do arquivo ("${nome}") deve ser igual ao id`);
        if (rel.split('/')[1] !== c.id.slice(0, 7)) err(`o arquivo deve ficar na pasta mensagens/${c.id.slice(0, 7)}/`);
        if (c.de && partes[4] !== c.de) err(`o "de" do id (${partes[4]}) difere do campo de (${c.de})`);
        if (c.tipo && partes[5] !== c.tipo) err(`o tipo do id (${partes[5]}) difere do campo tipo (${c.tipo})`);
      }
    }
    if (c.de && !/^[a-z0-9]+$/.test(c.de)) err('"de" deve ter só letras minúsculas e números');
    if (c.tipo && !TIPOS.includes(c.tipo)) err(`tipo inválido "${c.tipo}" (use: ${TIPOS.join(', ')})`);
    if (c.data && Number.isNaN(Date.parse(c.data))) err(`data inválida: ${c.data}`);
    if (c.responde_a) {
      for (const alvo of c.responde_a.split(',').map((s) => s.trim()).filter(Boolean)) {
        if (!ids.has(alvo)) err(`responde_a aponta para mensagem que não existe: ${alvo}`);
      }
    }
    if (!m.corpo.trim()) err('mensagem sem conteúdo');
    if (SEGREDOS.some((re) => re.test(m.texto))) err('possível credencial no texto: remova antes de publicar (o repositório é público)');
    if (/\[INSERIR[^\]]*\]/.test(m.texto)) avisos.push(`${rel}: ainda há placeholder [INSERIR ...] no texto`);
  }

  if (base) {
    try {
      const saida = execFileSync('git', ['diff', '--name-status', base, 'HEAD', '--', 'mensagens'], { cwd: RAIZ, encoding: 'utf8' });
      for (const linha of saida.split('\n').filter(Boolean)) {
        const [status, ...arq] = linha.split('\t');
        if (!status.startsWith('A')) erros.push(`${arq.join(' → ')}: mensagens publicadas não podem ser alteradas nem apagadas (${status}). Escreva uma nova mensagem com responde_a.`);
      }
    } catch {
      avisos.push(`não foi possível comparar com ${base}: a checagem "só acrescentar" foi ignorada`);
    }
  }

  avisos.forEach((a) => console.warn(`aviso: ${a}`));
  if (erros.length) {
    erros.forEach((e) => console.error(`erro: ${e}`));
    console.error(`\n${erros.length} erro(s) em ${msgs.length} mensagem(ns).`);
    return 1;
  }
  console.log(`ok: ${msgs.length} mensagem(ns) válida(s).`);
  return 0;
}

function indice() {
  const msgs = listarArquivos(PASTA).map(lerMensagem).filter((m) => m.campos);
  msgs.sort((a, b) => (a.campos.id < b.campos.id ? 1 : -1));
  const esc = (s) => String(s ?? '').replace(/\|/g, '\\|');
  const linhas = msgs.map(({ campos: c }) =>
    `| ${esc((c.data || '').slice(0, 16).replace('T', ' '))} | ${esc(c.de)} | ${esc(c.para)} | ${esc(c.tipo)} | ${esc(c.projeto)} | [${esc(c.assunto)}](mensagens/${c.id.slice(0, 7)}/${c.id}.md) |`);
  const texto = [
    '# Índice de mensagens',
    '',
    'Gerado por `node tools/cerebro.mjs indice`. Da mais recente para a mais antiga.',
    '',
    '| Data | De | Para | Tipo | Projeto | Assunto |',
    '|---|---|---|---|---|---|',
    ...linhas,
    '',
  ].join('\n');
  writeFileSync(join(RAIZ, 'INDICE.md'), texto);
  console.log(`INDICE.md atualizado (${msgs.length} mensagem(ns)).`);
}

function agora() {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Bahia', year: 'numeric', month: ' 2-digit'.replace(' ', ''), day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
  }).formatToParts(new Date()).map((x) => [x.type, x.value]));
  return { mes: `${p.year}-${p.month}`, dia: `${p.year}-${p.month}-${p.day}`, hm: `${p.hour}${p.minute}`, iso: `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}-03:00` };
}

const CORPOS = {
  aviso: '## O que aconteceu\n\n\n## Evidência\n\n\n## O que ainda não se sabe\n\n\n## Sugestão\n\n',
  mudanca: '## O que mudou\n\n\n## Por quê\n\n\n## Arquivos afetados\n\n\n## Como foi verificado\n(Se não foi testado, escreva "não verificado".)\n\n\n## O que pode ser afetado\n\n',
  handoff: '## Estado atual\n\n\n## Feito\n\n\n## Pendente\n\n\n## Não mexer (e por quê)\n\n\n## Dúvidas em aberto\n\n',
  pergunta: '## Pergunta\n\n\n## Contexto\n\n',
  resposta: '## Resposta\n\n\n## Base (fonte ou evidência)\n\n',
  decisao: '## Decisão\n\n\n## Quem decidiu\n\n\n## Motivo\n\n\n## Vale até quando\n\n',
};

function nova(a) {
  const faltando = ['de', 'tipo', 'projeto', 'assunto'].filter((k) => !a[k] || a[k] === true);
  if (faltando.length) { console.error(`faltam: ${faltando.map((k) => '--' + k).join(', ')}`); process.exit(1); }
  const de = slug(a.de);
  const tipo = slug(a.tipo);
  if (!TIPOS.includes(tipo)) { console.error(`tipo inválido "${a.tipo}". Use: ${TIPOS.join(', ')}`); process.exit(1); }
  const t = agora();
  const base = `${t.dia}-${t.hm}-${de}-${tipo}`;
  const dir = join(PASTA, t.mes);
  let id = base;
  for (let n = 2; existsSync(join(dir, `${id}.md`)); n++) id = `${base}-${String(n).padStart(2, '0')}`;
  const cab = [
    '---',
    `id: ${id}`,
    `de: ${de}`,
    `para: ${a.para && a.para !== true ? a.para : 'todas'}`,
    `tipo: ${tipo}`,
    `projeto: ${a.projeto}`,
    `assunto: ${a.assunto}`,
    `data: ${t.iso}`,
    ...(a['responde-a'] && a['responde-a'] !== true ? [`responde_a: ${a['responde-a']}`] : []),
    '---',
    '',
  ].join('\n');
  mkdirSync(dir, { recursive: true });
  const arquivo = join(dir, `${id}.md`);
  writeFileSync(arquivo, cab + CORPOS[tipo]);
  console.log(`criado: ${relative(RAIZ, arquivo).split(sep).join('/')}\nPreencha o corpo, depois rode: validar e indice.`);
}

const [cmd, ...resto] = process.argv.slice(2);
const a = {};
for (let i = 0; i < resto.length; i++) {
  if (resto[i].startsWith('--')) a[resto[i].slice(2)] = resto[i + 1] && !resto[i + 1].startsWith('--') ? resto[++i] : true;
}
if (cmd === 'validar') process.exit(validar({ base: typeof a.base === 'string' ? a.base : undefined }));
else if (cmd === 'indice') indice();
else if (cmd === 'nova') nova(a);
else console.log('uso: node tools/cerebro.mjs <nova|validar|indice>\n  nova --de <quem> --para <todas|lista> --tipo <tipo> --projeto <nome> --assunto "<texto>" [--responde-a <id>]\n  validar [--base <commit>]\n  indice');
