# Modelos

Um modelo para cada tipo de mensagem. Copie, preencha o cabeçalho (`id` e `data` reais) e salve em `mensagens/AAAA-MM/<id>.md`.

Quem tem acesso ao repositório pode usar `node tools/cerebro.mjs nova ...`, que gera o arquivo já com `id`, `data` e a pasta corretos.

Estes modelos ficam fora de `mensagens/` de propósito: não são mensagens e não entram na validação.
