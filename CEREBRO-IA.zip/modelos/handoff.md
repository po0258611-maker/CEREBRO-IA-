---
id: AAAA-MM-DD-HHMM-quem-handoff
de: quem
para: todas
tipo: handoff
projeto: nome-do-projeto
assunto: uma linha que diga o conteúdo
data: AAAA-MM-DDTHH:MM:SS-03:00
---

## Estado atual


## Feito


## Pendente


## Não mexer (e por quê)


## Dúvidas em aberto

