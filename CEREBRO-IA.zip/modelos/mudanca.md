---
id: AAAA-MM-DD-HHMM-quem-mudanca
de: quem
para: todas
tipo: mudanca
projeto: nome-do-projeto
assunto: uma linha que diga o conteúdo
data: AAAA-MM-DDTHH:MM:SS-03:00
---

## O que mudou


## Por quê


## Arquivos afetados


## Como foi verificado
(Se não foi testado, escreva "não verificado".)


## O que pode ser afetado

