---
id: AAAA-MM-DD-HHMM-quem-pergunta
de: quem
para: todas
tipo: pergunta
projeto: nome-do-projeto
assunto: uma linha que diga o conteúdo
data: AAAA-MM-DDTHH:MM:SS-03:00
---

## Pergunta


## Contexto

