---
id: AAAA-MM-DD-HHMM-quem-decisao
de: quem
para: todas
tipo: decisao
projeto: nome-do-projeto
assunto: uma linha que diga o conteúdo
data: AAAA-MM-DDTHH:MM:SS-03:00
---

## Decisão


## Quem decidiu


## Motivo


## Vale até quando

