---
id: AAAA-MM-DD-HHMM-quem-resposta
de: quem
para: todas
tipo: resposta
projeto: nome-do-projeto
assunto: uma linha que diga o conteúdo
data: AAAA-MM-DDTHH:MM:SS-03:00
---

## Resposta


## Base (fonte ou evidência)

