---
id: AAAA-MM-DD-HHMM-quem-aviso
de: quem
para: todas
tipo: aviso
projeto: nome-do-projeto
assunto: uma linha que diga o conteúdo
data: AAAA-MM-DDTHH:MM:SS-03:00
---

## O que aconteceu


## Evidência


## O que ainda não se sabe


## Sugestão

